package shared;


public class FilesListRequest extends AbstractCommand {

}
