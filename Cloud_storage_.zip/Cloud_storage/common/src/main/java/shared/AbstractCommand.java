package shared;

import java.io.Serializable;

public class AbstractCommand implements Serializable {

}
